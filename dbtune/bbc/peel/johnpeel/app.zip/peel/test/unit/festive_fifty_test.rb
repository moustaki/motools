require File.dirname(__FILE__) + '/../test_helper'

class FestiveFiftyTest < Test::Unit::TestCase
  fixtures :festive_fifties

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
