require File.dirname(__FILE__) + '/../test_helper'

class SessionTrackTest < Test::Unit::TestCase
  fixtures :session_tracks

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
