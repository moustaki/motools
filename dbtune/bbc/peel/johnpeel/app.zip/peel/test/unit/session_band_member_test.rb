require File.dirname(__FILE__) + '/../test_helper'

class SessionBandMemberTest < Test::Unit::TestCase
  fixtures :session_band_members

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
