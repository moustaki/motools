class SessionBandMember < ActiveRecord::Base
	belongs_to :session
end
